﻿using Assessment_247.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment_247.Services.Business
{
    public class MenuBusinessService
    {
        public string ReverseMenuItems(MenuModel menumodel)
        {
            //creating a char array for the letters to be put into
            char[] chararray = menumodel.Ingredient1.ToArray();
            char[] chararray2 = menumodel.Ingredient2.ToArray();
            //since the characters are now in an array, we can reverse them
            menumodel.Ingredient1.Reverse();
            menumodel.Ingredient2.Reverse();
            return menumodel.ToString();
        }
    }
}
