﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment_247.Models
{
    public class MenuModel
    {
        //model that displays text and has getters and setters
        [Display(Name = "Enter Name")]
        public string Name { get; set; }
       
        [Display(Name = "Enter Calories")]
        public int Calories { get; set; }

        [Display(Name = "Enter Ingredient1")]
        public string Ingredient1 { get; set; }

        [Display(Name = "Enter Ingredient2")]
        public string Ingredient2 { get; set; }

    }
}
