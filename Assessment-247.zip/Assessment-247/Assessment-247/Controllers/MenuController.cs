﻿using Assessment_247.Models;
using Assessment_247.Services.Business;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_247.Views
{
    public class MenuController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public IActionResult ReverseIngredient()
        {
            string name = (Request.Form["txtName"].ToString());
            int calories = Convert.ToInt32(Request.Form["txtCalories"].ToString());
            string ingredient1 = (Request.Form["txtIngredient1"].ToString());
            string ingredient2 = (Request.Form["txtIngredient2"].ToString());

            ingredient1.Reverse();
            ingredient2.Reverse();

            StringBuilder sbMenu = new StringBuilder();
            sbMenu.Append("<b> Name : </b> " + name + "</b>");
            sbMenu.Append("<b> Calories : </b> " + calories + "</b>");
            sbMenu.Append("<b> Ingredient 1 : </b> " + ingredient1 + "</b>");
            sbMenu.Append("<b> Name : </b> " + ingredient2 + "</b>");
            return Content(sbMenu.ToString());


        }

        //=============================================================

        public IActionResult Menu()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ReverseIngredients()
        {
            //Create an instance of the model
            MenuModel menuModel = new MenuModel();
            //Place values into the model
            menuModel.Name = Request.Form["Name"].ToString();
            menuModel.Calories = Convert.ToInt32(Request.Form["Calories"].ToString());
            menuModel.Ingredient1 = Request.Form["Ingredient1"].ToString();
            menuModel.Ingredient2 = Request.Form["Ingredient2"].ToString();

            //Create an instance of the Business layer
            MenuBusinessService businessLayer = new MenuBusinessService();

            string reversedingredients = businessLayer.ReverseMenuItems(menuModel);

            StringBuilder sbIngredients = new StringBuilder();

            sbIngredients.Append("<b> Name : </b> " + menuModel.Name + "</br>");
            sbIngredients.Append("<b> Calories : </b> " + menuModel.Calories + "</br>");
            sbIngredients.Append("<b> Ingredient1 : </b> " + menuModel.Ingredient1 + "</br>");
            sbIngredients.Append("<b> Ingredient2 : </b> " + menuModel.Ingredient2 + "</br>");
            //sbIngredients.Append("<b> IngredientReversed : </b> " + b + "</br>");

            ViewBag.reversed = sbIngredients;
            return View("Menu");
        }



    }
}
